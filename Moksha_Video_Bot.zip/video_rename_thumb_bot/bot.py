from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import tempfile
import uuid
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, InputFile, Update
from telegram.error import TelegramError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
DUMP_CHAT_ID = os.getenv("DUMP_CHAT_ID", "").strip()
OWNER_ID_RAW = os.getenv("OWNER_ID", "").strip()
MAX_CONCURRENT = max(1, min(10, int(os.getenv("MAX_CONCURRENT", "5"))))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

BASE_DIR = Path(os.getenv("DATA_DIR", "data"))
THUMB_PATH = BASE_DIR / "thumbnail.jpg"
WORK_DIR = Path(os.getenv("WORK_DIR", "/tmp/video-rename-thumb-work"))
MAX_NAME_LENGTH = 180
VIDEO_EXTENSIONS = {
    ".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v", ".mpeg", ".mpg",
    ".ts", ".3gp", ".wmv", ".flv", ".ogv",
}

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=LOG_LEVEL,
)
logger = logging.getLogger("moksha-video-bot")


def normalize_chat_id(value: str) -> int | str:
    try:
        return int(value)
    except (TypeError, ValueError):
        return value


def is_allowed(update: Update) -> bool:
    if not OWNER_ID_RAW:
        return True
    try:
        owner_id = int(OWNER_ID_RAW)
    except ValueError:
        logger.error("OWNER_ID must be a numeric Telegram user ID")
        return False
    user = update.effective_user
    return bool(user and user.id == owner_id)


async def reject_if_not_allowed(update: Update) -> bool:
    if is_allowed(update):
        return False
    message = update.effective_message
    if message:
        await message.reply_text("⛔ البوت ده مخصص لصاحبه فقط.")
    elif update.callback_query:
        await update.callback_query.answer("مش مسموح لك تستخدم البوت ده.", show_alert=True)
    return True


def clean_filename(value: str) -> str:
    value = value.strip().replace("\n", " ").replace("\r", " ")
    value = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", value)
    value = re.sub(r"\s+", " ", value).strip(" .")
    return value[:MAX_NAME_LENGTH].strip(" .")


def media_info(message) -> dict[str, Any] | None:
    if message.video:
        item = message.video
        name = item.file_name or f"video_{message.message_id}.mp4"
        return {
            "file_id": item.file_id,
            "original_name": name,
            "media_kind": "video",
            "file_size": item.file_size or 0,
            "caption": message.caption,
            "source_message_id": message.message_id,
        }
    if message.document:
        item = message.document
        name = item.file_name or f"file_{message.message_id}"
        mime = (item.mime_type or "").lower()
        if mime.startswith("video/") or Path(name).suffix.lower() in VIDEO_EXTENSIONS:
            return {
                "file_id": item.file_id,
                "original_name": name,
                "media_kind": "document",
                "file_size": item.file_size or 0,
                "caption": message.caption,
                "source_message_id": message.message_id,
            }
    return None


def main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🚀 المود الأول — معالجة جماعية", callback_data="mode:batch")],
        [InlineKeyboardButton("🎛️ المود الثاني — إعدادات كل فيديو", callback_data="mode:single")],
        [InlineKeyboardButton("🖼️ إدارة الصورة المحفوظة", callback_data="thumb:status")],
        [InlineKeyboardButton("📊 حالة المهام", callback_data="queue:status")],
    ])


def settings_keyboard(job_id: str, job: dict[str, Any]) -> InlineKeyboardMarkup:
    name_label = "📌 الاسم الحالي محدد" if job.get("name_choice") == "keep" else "📌 الاحتفاظ بالاسم الحالي"
    thumb_label = "🖼️ استخدام الصورة المحفوظة" if job.get("use_thumbnail", True) else "🚫 بدون صورة مصغرة"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✏️ تغيير اسم الملف", callback_data=f"job:rename:{job_id}")],
        [InlineKeyboardButton(name_label, callback_data=f"job:keep:{job_id}")],
        [InlineKeyboardButton(thumb_label, callback_data=f"job:thumb:{job_id}")],
        [InlineKeyboardButton("✅ تنفيذ", callback_data=f"job:run:{job_id}")],
        [InlineKeyboardButton("❌ إلغاء الفيديو ده", callback_data=f"job:cancel:{job_id}")],
    ])


def job_summary(job: dict[str, Any]) -> str:
    caption = job.get("caption")
    caption_state = "موجود، هيفضل زي ما هو" if caption else "مفيش كابشن أصلي"
    thumb_state = "الصورة المحفوظة" if job.get("use_thumbnail", True) else "بدون صورة مصغرة"
    return (
        "🎬 إعدادات الفيديو\n\n"
        f"📁 الاسم الحالي: {job['original_name']}\n"
        f"📝 الكابشن: {caption_state}\n"
        f"🖼️ الصورة: {thumb_state}\n\n"
        "اختار تغيير الاسم أو الاحتفاظ بالاسم الحالي، وبعدها اضغط تنفيذ.\n"
        "كل فيديو له إعداداته المستقلة."
    )


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    await update.effective_message.reply_text(
        "🤖 أهلاً بيك في بوت الصور المصغرة للفيديوهات\n\n"
        "1) ابعت صورة عشان يحفظها كصورة افتراضية.\n"
        "2) اختار مود المعالجة.\n"
        "3) الفيديوهات النهائية هتتبعت لقناة الـ Dump بالكابشن الأصلي فقط.\n\n"
        "🚀 الجماعي: يعالج تلقائيًا مع الاحتفاظ باسم الملف الأصلي.\n"
        "🎛️ الفردي: كل فيديو له رسالة إعدادات وأزرار مستقلة.\n\n"
        "الأوامر: /start /help /queue /thumbnail /cancelname",
        reply_markup=main_keyboard(),
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    await start(update, context)


async def mode_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    query = update.callback_query
    await query.answer()
    mode = query.data.split(":", 1)[1]
    context.user_data["mode"] = mode
    if mode == "batch":
        text = (
            "🚀 تم اختيار المعالجة الجماعية.\n"
            "ابعت الفيديوهات واحد ورا التاني؛ هتدخل قائمة الانتظار وتتعمل تلقائيًا.\n"
            f"عدد العمليات المتزامنة الحالي: {MAX_CONCURRENT}.\n"
            "اسم الملف هيفضل زي ما هو، والكابشن الأصلي هيفضل زي ما هو."
        )
    else:
        text = (
            "🎛️ تم اختيار التحكم الفردي.\n"
            "ابعت أي فيديو، وهيرد البوت على نفس الفيديو بإعداداته وأزراره.\n"
            "تقدر تغيّر الاسم أو تحتفظ بالاسم الحالي، وتختار استخدام الصورة المحفوظة أو بدون صورة."
        )
    await query.message.reply_text(text)


async def save_thumbnail(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    message = update.effective_message
    if not (message.photo or (message.document and (message.document.mime_type or "").startswith("image/"))):
        return
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="thumb_", dir=WORK_DIR) as tmp:
        tmpdir = Path(tmp)
        if message.photo:
            photo_file = message.photo[-1]
            tg_file = await context.bot.get_file(photo_file.file_id)
            downloaded = tmpdir / "incoming_image"
            await tg_file.download_to_drive(custom_path=downloaded)
        else:
            tg_file = await context.bot.get_file(message.document.file_id)
            downloaded = tmpdir / "incoming_image"
            await tg_file.download_to_drive(custom_path=downloaded)
        try:
            converted = tmpdir / "thumbnail.jpg"
            with Image.open(downloaded) as image_obj:
                image_obj = ImageOps.exif_transpose(image_obj).convert("RGB")
                image_obj.thumbnail((320, 320))
                quality = 88
                while True:
                    image_obj.save(converted, "JPEG", quality=quality, optimize=True)
                    if converted.stat().st_size <= 190_000 or quality <= 40:
                        break
                    quality -= 8
                if converted.stat().st_size > 200_000:
                    raise ValueError("الصورة أكبر من الحد المسموح بعد التحويل")
            replace_tmp = BASE_DIR / "thumbnail.new.jpg"
            shutil.copy2(converted, replace_tmp)
            os.replace(replace_tmp, THUMB_PATH)
        except Exception as exc:
            logger.exception("Failed to save thumbnail")
            await message.reply_text(f"❌ مقدرتش أحفظ الصورة. جرّب صورة تانية. ({type(exc).__name__})")
            return
    await message.reply_text("✅ حفظت الصورة المصغرة الافتراضية. هستخدمها تلقائيًا مع الفيديوهات الجديدة.")


async def thumbnail_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    if THUMB_PATH.exists():
        await update.effective_message.reply_photo(
            photo=THUMB_PATH.read_bytes(),
            caption="🖼️ دي الصورة المصغرة المحفوظة حاليًا. ابعت صورة جديدة لاستبدالها.",
        )
    else:
        await update.effective_message.reply_text("مفيش صورة محفوظة لسه. ابعت صورة عشان أحفظها.")


async def receive_media(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    message = update.effective_message
    info = media_info(message)
    if not info:
        await message.reply_text("ابعت فيديو كـ Video أو كـ File/Document.")
        return
    if not THUMB_PATH.exists():
        await message.reply_text("🖼️ ابعت الصورة المصغرة الأول، وبعدها ابعت الفيديوهات.")
        return
    mode = context.user_data.get("mode")
    if mode not in {"batch", "single"}:
        await message.reply_text("اختار مود الأول من الأزرار دي:", reply_markup=main_keyboard())
        return

    job_id = uuid.uuid4().hex[:10]
    job = {
        **info,
        "job_id": job_id,
        "owner_id": update.effective_user.id,
        "chat_id": update.effective_chat.id,
        "mode": mode,
        "new_name": info["original_name"],
        "name_choice": "keep",
        "use_thumbnail": True,
        "status": "waiting" if mode == "batch" else "settings",
        "settings_message_id": None,
        "created_at": asyncio.get_running_loop().time(),
    }
    jobs = context.application.bot_data.setdefault("jobs", {})
    jobs[job_id] = job

    if mode == "batch":
        await message.reply_text(
            f"📥 دخلت قائمة الانتظار: {info['original_name']}\n"
            f"🧾 الكابشن الأصلي محفوظ.\n"
            f"⏳ هتتعالج تلقائيًا (حد أقصى {MAX_CONCURRENT} فيديوهات في نفس الوقت)."
        )
        context.application.create_task(process_job(context.application, job_id), name=f"video-job-{job_id}")
    else:
        reply = await message.reply_text(job_summary(job), reply_markup=settings_keyboard(job_id, job))
        job["settings_message_id"] = reply.message_id


async def job_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    query = update.callback_query
    parts = query.data.split(":")
    if len(parts) != 3:
        await query.answer()
        return
    _, action, job_id = parts
    job = context.application.bot_data.get("jobs", {}).get(job_id)
    if not job or job["owner_id"] != update.effective_user.id:
        await query.answer("العملية مش موجودة أو مش بتاعتك.", show_alert=True)
        return
    await query.answer()
    if job["status"] not in {"settings"}:
        await query.answer("الإعدادات دي اتقفلت بالفعل.", show_alert=True)
        return

    if action == "rename":
        context.user_data["awaiting_name_for_job"] = job_id
        job["name_choice"] = "rename_pending"
        await query.message.reply_text(
            f"✏️ ابعت الاسم الجديد للملف ده:\n{job['original_name']}\n\n"
            "اكتب الاسم من غير الامتداد لو عاوز الامتداد الأصلي يفضل زي ما هو.\n"
            "للرجوع من غير تغيير الاسم استخدم /cancelname."
        )
        return
    if action == "keep":
        job["new_name"] = job["original_name"]
        job["name_choice"] = "keep"
    elif action == "thumb":
        job["use_thumbnail"] = not job.get("use_thumbnail", True)
    elif action == "cancel":
        job["status"] = "cancelled"
        await query.edit_message_text("❌ تم إلغاء الفيديو ده. باقي الفيديوهات مش هتتأثر.")
        return
    elif action == "run":
        if job.get("name_choice") == "rename_pending":
            await query.message.reply_text("اكتب الاسم الجديد الأول أو اختار الاحتفاظ بالاسم الحالي.")
            return
        job["status"] = "waiting"
        await query.edit_message_text("📥 اتضافت المعالجة لقائمة الانتظار. هبعتلك تحديث لما تخلص.")
        context.application.create_task(process_job(context.application, job_id), name=f"video-job-{job_id}")
        return
    await query.edit_message_text(job_summary(job), reply_markup=settings_keyboard(job_id, job))


async def receive_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    job_id = context.user_data.get("awaiting_name_for_job")
    if not job_id:
        await update.effective_message.reply_text("اختار مود وابعت فيديو، أو استخدم /help.")
        return
    job = context.application.bot_data.get("jobs", {}).get(job_id)
    if not job or job.get("status") != "settings":
        context.user_data.pop("awaiting_name_for_job", None)
        await update.effective_message.reply_text("الفيديو ده مش مستني اسم دلوقتي. افتح إعداداته تاني.")
        return
    new_name = clean_filename(update.effective_message.text or "")
    if not new_name or new_name.startswith("/"):
        await update.effective_message.reply_text("❌ الاسم مش صالح. ابعت اسم ملف واضح.")
        return
    old_ext = Path(job["original_name"]).suffix
    if not Path(new_name).suffix and old_ext:
        new_name += old_ext
    if len(Path(new_name).suffix) > 12:
        await update.effective_message.reply_text("❌ الامتداد شكله غير صحيح. جرّب اسم تاني.")
        return
    job["new_name"] = new_name
    job["name_choice"] = "rename"
    context.user_data.pop("awaiting_name_for_job", None)
    settings_message_id = job.get("settings_message_id")
    if settings_message_id:
        try:
            await context.bot.edit_message_text(
                chat_id=job["chat_id"],
                message_id=settings_message_id,
                text=job_summary(job),
                reply_markup=settings_keyboard(job_id, job),
            )
        except TelegramError:
            pass
    await update.effective_message.reply_text(f"✅ الاسم اتحدد: `{new_name}`\nاضغط تنفيذ من رسالة إعدادات الفيديو.", parse_mode="Markdown")


async def process_job(application: Application, job_id: str) -> None:
    jobs = application.bot_data.get("jobs", {})
    job = jobs.get(job_id)
    if not job or job.get("status") not in {"waiting"}:
        return
    semaphore: asyncio.Semaphore = application.bot_data["semaphore"]
    async with semaphore:
        # Recheck after waiting for a slot.
        if job.get("status") != "waiting":
            return
        job["status"] = "running"
        temp_dir: Path | None = None
        try:
            WORK_DIR.mkdir(parents=True, exist_ok=True)
            temp_dir = Path(tempfile.mkdtemp(prefix=f"job_{job_id}_", dir=WORK_DIR))
            source_path = temp_dir / "source.bin"
            output_name = clean_filename(job.get("new_name") or job["original_name"])
            output_path = temp_dir / output_name

            file_obj = await application.bot.get_file(job["file_id"])
            await file_obj.download_to_drive(custom_path=source_path)
            if not source_path.exists() or source_path.stat().st_size == 0:
                raise RuntimeError("الملف اللي نزل من تيليجرام فاضي")

            thumb_path: Path | None = None
            if job.get("use_thumbnail", True):
                if not THUMB_PATH.exists():
                    raise RuntimeError("الصورة الافتراضية مش موجودة؛ ابعت الصورة تاني")
                thumb_path = temp_dir / "thumbnail.jpg"
                shutil.copy2(THUMB_PATH, thumb_path)

            # Upload the downloaded file directly with a new Telegram filename.
            # Avoid duplicating large video bytes on disk.
            output_path = source_path
            dump_target = normalize_chat_id(DUMP_CHAT_ID)
            caption = job.get("caption")
            with output_path.open("rb") as file_handle:
                common: dict[str, Any] = {
                    "chat_id": dump_target,
                    "caption": caption,
                }
                if job["media_kind"] == "video":
                    common["video"] = InputFile(file_handle, filename=output_name)
                    common["supports_streaming"] = True
                    if thumb_path:
                        with thumb_path.open("rb") as thumb_handle:
                            common["thumbnail"] = InputFile(thumb_handle, filename="thumbnail.jpg")
                            await application.bot.send_video(**common)
                    else:
                        await application.bot.send_video(**common)
                else:
                    common["document"] = InputFile(file_handle, filename=output_name)
                    if thumb_path:
                        with thumb_path.open("rb") as thumb_handle:
                            common["thumbnail"] = InputFile(thumb_handle, filename="thumbnail.jpg")
                            await application.bot.send_document(**common)
                    else:
                        await application.bot.send_document(**common)

            job["status"] = "done"
            await application.bot.send_message(
                chat_id=job["chat_id"],
                text=f"✅ خلص الفيديو واتبعَت لقناة الـ Dump.\n📁 {output_name}",
            )
            settings_message_id = job.get("settings_message_id")
            if settings_message_id:
                try:
                    await application.bot.edit_message_reply_markup(
                        chat_id=job["chat_id"], message_id=settings_message_id, reply_markup=None
                    )
                except TelegramError:
                    pass
        except Exception as exc:
            job["status"] = "error"
            logger.exception("Job %s failed", job_id)
            detail = str(exc)
            if len(detail) > 250:
                detail = detail[:250]
            try:
                await application.bot.send_message(
                    chat_id=job["chat_id"],
                    text=(
                        f"❌ فشلت معالجة الفيديو: {job['original_name']}\n"
                        "اتمسحت الملفات المؤقتة تلقائيًا.\n"
                        f"السبب المختصر: {detail}\n\n"
                        "لو الملف كبير، راجع حدود Telegram Bot API أو استخدم Local Bot API Server."
                    ),
                )
            except TelegramError:
                pass
        finally:
            # Critical storage safeguard: delete this task's entire working folder on
            # success, failure, or cancellation. The saved thumbnail is outside WORK_DIR.
            if temp_dir:
                shutil.rmtree(temp_dir, ignore_errors=True)
            job["finished_at"] = asyncio.get_running_loop().time()


async def queue_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    jobs = context.application.bot_data.get("jobs", {})
    counts = {key: 0 for key in ("settings", "waiting", "running", "done", "error", "cancelled")}
    for job in jobs.values():
        if job.get("owner_id") == update.effective_user.id:
            status = job.get("status", "error")
            counts[status] = counts.get(status, 0) + 1
    await update.effective_message.reply_text(
        "📊 حالة المهام الحالية\n\n"
        f"⚙️ إعدادات لم يبدأ تنفيذها: {counts['settings']}\n"
        f"⏳ في الانتظار: {counts['waiting']}\n"
        f"🔄 قيد التنفيذ: {counts['running']}\n"
        f"✅ اكتملت: {counts['done']}\n"
        f"❌ فشلت: {counts['error']}\n"
        f"🚫 ملغاة: {counts['cancelled']}\n\n"
        f"الحد الأقصى للتوازي: {MAX_CONCURRENT}"
    )


async def cancel_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    context.user_data.pop("awaiting_name_for_job", None)
    await update.effective_message.reply_text("تمام، لغيت انتظار الاسم. الفيديو نفسه لسه موجود في إعداداته.")


async def unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    await update.effective_message.reply_text("مش فاهم الأمر. استخدم /help.")


async def post_init(application: Application) -> None:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    # Remove abandoned temporary task folders left by an unclean previous shutdown.
    for item in WORK_DIR.iterdir():
        if item.is_dir():
            shutil.rmtree(item, ignore_errors=True)
        elif item.is_file():
            try:
                item.unlink()
            except OSError:
                logger.warning("Could not remove stale temporary file: %s", item)
    application.bot_data["semaphore"] = asyncio.Semaphore(MAX_CONCURRENT)
    logger.info("Bot started; max concurrent jobs=%s; dump=%s", MAX_CONCURRENT, DUMP_CHAT_ID)


def main() -> None:
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is missing. Set it as an environment variable.")
    if not DUMP_CHAT_ID:
        raise RuntimeError("DUMP_CHAT_ID is missing. Set it to your private channel ID or @channelusername.")

    builder = Application.builder().token(BOT_TOKEN).post_init(post_init)
    # Optional base URL configuration for a self-hosted Telegram Bot API server.
    api_base = os.getenv("TELEGRAM_API_BASE_URL", "").strip()
    file_base = os.getenv("TELEGRAM_FILE_BASE_URL", "").strip()
    if api_base:
        builder = builder.base_url(api_base)
    if file_base:
        builder = builder.base_file_url(file_base)
    app = builder.build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("queue", queue_status))
    app.add_handler(CommandHandler("thumbnail", thumbnail_command))
    app.add_handler(CommandHandler("cancelname", cancel_name))
    app.add_handler(CallbackQueryHandler(mode_callback, pattern=r"^mode:(batch|single)$"))
    app.add_handler(CallbackQueryHandler(job_callback, pattern=r"^job:(rename|keep|thumb|run|cancel):[a-f0-9]+$"))
    app.add_handler(CallbackQueryHandler(
        lambda update, context: thumb_status_callback(update, context), pattern=r"^thumb:status$"
    ))
    app.add_handler(CallbackQueryHandler(
        lambda update, context: queue_status_callback(update, context), pattern=r"^queue:status$"
    ))
    app.add_handler(MessageHandler(filters.PHOTO | (filters.Document.IMAGE), save_thumbnail))
    app.add_handler(MessageHandler(filters.VIDEO | filters.Document.ALL, receive_media))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, receive_text))

    logger.info("Starting polling...")
    app.run_polling(drop_pending_updates=False)


async def thumb_status_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    query = update.callback_query
    await query.answer()
    if THUMB_PATH.exists():
        await query.message.reply_photo(photo=THUMB_PATH.read_bytes(), caption="🖼️ الصورة المحفوظة حاليًا. ابعت صورة جديدة لاستبدالها.")
    else:
        await query.message.reply_text("مفيش صورة محفوظة. ابعت صورة الأول.")


async def queue_status_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if await reject_if_not_allowed(update):
        return
    query = update.callback_query
    await query.answer()
    jobs = context.application.bot_data.get("jobs", {})
    counts = {key: 0 for key in ("settings", "waiting", "running", "done", "error", "cancelled")}
    for job in jobs.values():
        if job.get("owner_id") == update.effective_user.id:
            counts[job.get("status", "error")] += 1
    await query.message.reply_text(
        "📊 حالة المهام\n"
        f"⚙️ إعدادات: {counts['settings']} | ⏳ انتظار: {counts['waiting']}\n"
        f"🔄 تنفيذ: {counts['running']} | ✅ مكتملة: {counts['done']}\n"
        f"❌ فاشلة: {counts['error']} | 🚫 ملغاة: {counts['cancelled']}\n"
        f"التوازي الأقصى: {MAX_CONCURRENT}"
    )


if __name__ == "__main__":
    main()
